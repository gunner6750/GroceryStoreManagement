/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author Hungly1402
 */
public class Product {
    private 
        String ID;
        String name;

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public void setInPrice(Double inPrice) {
        this.inPrice = inPrice;
    }

    public void setOutPrice(Double outPrice) {
        this.outPrice = outPrice;
    }
        String category;
        Integer quantity;
        Double inPrice;
        Double outPrice;

    public Product(String ID, String name, String category, int quantity, double inPrice, double outPrice) {
        this.ID = ID;
        this.name = name;
        this.category = category;
        this.quantity = quantity;
        this.inPrice = inPrice;
        this.outPrice = outPrice;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public Double getInPrice() {
        return inPrice;
    }
    
    public Double getOutPrice() {
        return outPrice;
    }
    
    void describe(){
        System.out.println("Product's ID: " + ID + ", Product's name: " + name + ", Product's category: " + category + ", Product's quantity: " + quantity + ", Product's inPrice: " + inPrice + ", Product's outPrice: " + outPrice);
    }
}
