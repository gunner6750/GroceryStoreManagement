/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author khang
 */
abstract public class Person {
    private
        String name;
        String ID;
        String PhoneNo;
    public
        Person(String name, String ID, String PhoneNo){
            this.name = name;
            this.ID = ID;
            this.PhoneNo = PhoneNo;
        }
        public String getName(){
            return name;
        } 
        public String getID(){
            return ID;
        }
        public String getPhoneNo(){
            return PhoneNo;
        }
        abstract void describe();
}
