/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author HP
 */
public class Customer extends Person{

    public Customer(String name, String ID, String PhoneNo) {
        super(name, ID, PhoneNo);
    }

    @Override
    void describe() {
        System.out.println("Customer's name: " + getName() + ", Customer's ID: " + getID() + ", Customer's PhoneNo: " + getPhoneNo());
    }
}
