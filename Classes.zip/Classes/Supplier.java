/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author HP
 */
public class Supplier {
    private 
        String ID;
        String name;
        String barCode;
    public Supplier(String ID, String name, String barCode) {
        this.ID = ID;
        this.name = name;
        this.barCode = barCode;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }
    public String getID() {
        return ID;
    }
    public String getName() {
        return name;
    }
    public String getBarCode() {
        return barCode;
    }
    void describe(){
        System.out.println("Supplier's ID: " + ID + ", Supplier's name: " + name + ", Supplier's barCode: " + barCode);
    }
}
