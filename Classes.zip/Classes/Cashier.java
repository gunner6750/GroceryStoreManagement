/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author khang
 */
public class Cashier extends Employee implements accessCheckOut, accessWarehouse{

    public Cashier(String name, String ID, String PhoneNo, String role) {
        super(name, ID, PhoneNo, role);
    }
    
    public void accessCO(int a){
        System.out.println("Accessing CheckOut Number!!" + a);
    }
    public void accessWH(){
        System.out.println("Accessing Warehouse as a Cashier!!!");
    }
}
