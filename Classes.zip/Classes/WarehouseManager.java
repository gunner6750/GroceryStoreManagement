/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author khang
 */
public class WarehouseManager extends Employee implements accessWarehouse {

    public WarehouseManager(String name, String ID, String PhoneNo, String role) {
        super(name, ID, PhoneNo, role);
    }
    
    public void accessWH(){
        System.out.println("Accessing Warehouse as a Warehouse Manager");
    }
}
