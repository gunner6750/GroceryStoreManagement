/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.grocerystore;

/**
 *
 * @author HP
 */
public class GroceryStore {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
